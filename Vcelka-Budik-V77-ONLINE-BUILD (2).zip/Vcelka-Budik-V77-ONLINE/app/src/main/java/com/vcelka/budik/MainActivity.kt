package com.vcelka.budik

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TimePicker
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var urlInput: TextInputEditText
    private lateinit var timePicker: TimePicker
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("vcelka_budik", Context.MODE_PRIVATE)
        urlInput = findViewById(R.id.urlInput)
        timePicker = findViewById(R.id.timePicker)
        statusText = findViewById(R.id.statusText)
        timePicker.setIs24HourView(true)

        urlInput.setText(prefs.getString("ytUrl", "https://music.youtube.com/watch?v=JGwWNGJdvx8"))
        timePicker.hour = prefs.getInt("hour", 7)
        timePicker.minute = prefs.getInt("minute", 0)

        updateStatus()

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener { saveAndSchedule() }
        findViewById<MaterialButton>(R.id.btnTest).setOnClickListener { testNow() }
        findViewById<MaterialButton>(R.id.btnCancel).setOnClickListener { cancelAlarm() }
        findViewById<MaterialButton>(R.id.btnOpenYT).setOnClickListener {
            val url = urlInput.text.toString()
            val vid = extractVideoId(url)
            if(vid!=null){
                try{
                    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://music.youtube.com/watch?v=$vid"))
                    startActivity(intent)
                }catch(e: Exception){ Toast.makeText(this, "Nainstaluj YouTube Music", Toast.LENGTH_SHORT).show() }
            }
        }

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.S){
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if(!am.canScheduleExactAlarms()){
                Toast.makeText(this, "Povol přesné budíky v nastavení", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            }
        }
    }

    private fun saveAndSchedule(){
        val url = urlInput.text.toString().trim()
        if(url.isEmpty()){ Toast.makeText(this, "Vlož URL", Toast.LENGTH_SHORT).show(); return }
        val vid = extractVideoId(url)
        if(vid==null){ Toast.makeText(this, "Neplatné URL", Toast.LENGTH_SHORT).show(); return }
        val hour = timePicker.hour
        val minute = timePicker.minute
        prefs.edit().putString("ytUrl", url).putString("videoId", vid).putInt("hour", hour).putInt("minute", minute).putBoolean("enabled", true).apply()
        scheduleAlarm(hour, minute, vid, url)
        Toast.makeText(this, "✅ Budík nastaven $hour:${"%02d".format(minute)}", Toast.LENGTH_LONG).show()
        updateStatus()
    }

    private fun scheduleAlarm(hour: Int, minute: Int, videoId: String, url: String){
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply{ putExtra("videoId", videoId); putExtra("url", url) }
        val pi = PendingIntent.getBroadcast(this, 77, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply{
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            if(timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        prefs.edit().putLong("nextTs", cal.timeInMillis).apply()
    }

    private fun cancelAlarm(){
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 77, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
        prefs.edit().putBoolean("enabled", false).apply()
        Toast.makeText(this, "Zrušeno", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun testNow(){
        val url = urlInput.text.toString()
        val vid = extractVideoId(url) ?: return
        startActivity(Intent(this, AlarmActivity::class.java).apply{ putExtra("videoId", vid); putExtra("url", url); putExtra("test", true) })
    }

    private fun updateStatus(){
        val enabled = prefs.getBoolean("enabled", false)
        val nextTs = prefs.getLong("nextTs", 0L)
        val h = prefs.getInt("hour", 7)
        val m = prefs.getInt("minute", 0)
        statusText.text = if(enabled && nextTs>0) "✅ AKTIVNÍ - ${Date(nextTs)} ($h:${"%02d".format(m)}) - probudí ze spánku" else "❌ Neaktivní"
    }

    private fun extractVideoId(url: String): String?{
        var u = url.trim()
        if(u.contains("youtu.be/")) return u.substringAfter("youtu.be/").substringBefore("?").substringBefore("&").take(11)
        if(u.contains("v=")){
            return try{ android.net.Uri.parse(u).getQueryParameter("v")?.take(11) }catch(e: Exception){ null }
        }
        return Regex("([A-Za-z0-9_-]{11})").find(u)?.value
    }
}
