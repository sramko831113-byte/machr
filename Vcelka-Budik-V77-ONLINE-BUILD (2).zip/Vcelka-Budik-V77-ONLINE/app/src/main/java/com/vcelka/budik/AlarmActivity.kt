package com.vcelka.budik

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.util.*

class AlarmActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var videoId: String = ""
    private var isTest = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1){ setShowWhenLocked(true); setTurnScreenOn(true) }
        else{ window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){ km.requestDismissKeyguard(this, null) }
        setContentView(R.layout.activity_alarm)
        videoId = intent.getStringExtra("videoId") ?: ""
        val url = intent.getStringExtra("url") ?: ""
        isTest = intent.getBooleanExtra("test", false)
        findViewById<TextView>(R.id.alarmTitle).text = if(isTest) "🧪 TEST - $videoId" else "🔔 BUDÍK - $videoId"
        findViewById<TextView>(R.id.alarmUrl).text = url
        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        val ytEmbed = "https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&enablejsapi=1"
        webView.loadUrl(ytEmbed)
        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener { stopAlarm() }
        findViewById<MaterialButton>(R.id.btnSnooze).setOnClickListener { snooze() }
        findViewById<MaterialButton>(R.id.btnOpenApp).setOnClickListener {
            try{
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=$videoId"))
                intent.setPackage("com.google.android.apps.youtube.music")
                startActivity(intent)
            }catch(e: Exception){
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=$videoId")))
            }
        }
    }
    private fun stopAlarm(){
        stopService(Intent(this, AlarmService::class.java))
        if(!isTest){
            val prefs = getSharedPreferences("vcelka_budik", Context.MODE_PRIVATE)
            val hour = prefs.getInt("hour", 7)
            val minute = prefs.getInt("minute", 0)
            val cal = Calendar.getInstance().apply{ set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); add(Calendar.DAY_OF_YEAR, 1) }
            val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val intent = Intent(this, AlarmReceiver::class.java).apply{ putExtra("videoId", videoId); putExtra("url", prefs.getString("ytUrl","")) }
            val pi = android.app.PendingIntent.getBroadcast(this, 77, intent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            prefs.edit().putLong("nextTs", cal.timeInMillis).apply()
        }
        finish()
    }
    private fun snooze(){
        stopService(Intent(this, AlarmService::class.java))
        val cal = Calendar.getInstance().apply{ add(Calendar.MINUTE, 5) }
        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java).apply{ putExtra("videoId", videoId) }
        val pi = android.app.PendingIntent.getBroadcast(this, 77, intent, android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
        am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        finish()
    }
}
