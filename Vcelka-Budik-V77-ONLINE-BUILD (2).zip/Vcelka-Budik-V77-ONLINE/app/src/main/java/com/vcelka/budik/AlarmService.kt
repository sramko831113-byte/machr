package com.vcelka.budik

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val videoId = intent?.getStringExtra("videoId") ?: ""
        val channelId = "vcelka_budik_channel"
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(channelId, "Včelka Budík", NotificationManager.IMPORTANCE_HIGH).apply{
                description = "Systémový budík"; enableVibration(false); setSound(null, null); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val fullScreenIntent = Intent(this, AlarmActivity::class.java).apply{ putExtra("videoId", videoId); putExtra("url", intent?.getStringExtra("url") ?: "") }
        val fullScreenPending = PendingIntent.getActivity(this, 78, fullScreenIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("🐝 Včelka Budík zvoní")
            .setContentText("Přehrávám $videoId")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPending, true)
            .setOngoing(true).build()
        startForeground(77, notification)
        try{
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply{
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@AlarmService, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI)
                isLooping = true; prepare(); start()
            }
        }catch(e: Exception){}
        return START_STICKY
    }
    override fun onDestroy() { mediaPlayer?.stop(); mediaPlayer?.release(); super.onDestroy() }
}
