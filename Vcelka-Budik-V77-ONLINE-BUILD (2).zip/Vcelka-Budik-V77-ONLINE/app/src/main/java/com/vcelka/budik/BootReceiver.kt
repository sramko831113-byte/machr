package com.vcelka.budik

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if(intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("vcelka_budik", Context.MODE_PRIVATE)
        if(!prefs.getBoolean("enabled", false)) return
        val hour = prefs.getInt("hour", 7)
        val minute = prefs.getInt("minute", 0)
        val videoId = prefs.getString("videoId", null) ?: return
        val url = prefs.getString("ytUrl", "") ?: ""
        val cal = Calendar.getInstance().apply{
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            if(timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarmIntent = Intent(context, AlarmReceiver::class.java).apply{ putExtra("videoId", videoId); putExtra("url", url) }
        val pi = PendingIntent.getBroadcast(context, 77, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}
