package com.vcelka.budik

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val videoId = intent.getStringExtra("videoId") ?: context.getSharedPreferences("vcelka_budik", Context.MODE_PRIVATE).getString("videoId", null) ?: return
        val url = intent.getStringExtra("url") ?: ""
        val serviceIntent = Intent(context, AlarmService::class.java).apply{ putExtra("videoId", videoId); putExtra("url", url) }
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent) else context.startService(serviceIntent)
        val alarmIntent = Intent(context, AlarmActivity::class.java).apply{
            putExtra("videoId", videoId); putExtra("url", url); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        context.startActivity(alarmIntent)
    }
}
