# FIXED - Namespace error opraven

Chyba: Namespace not specified

Oprava: v app/build.gradle přidáno:
android {
    namespace 'com.vcelka.budik'
    ...
}

A přidán gradle wrapper 8.6 pro kompatibilitu s Android Studio.

Postup:
1. Rozbal ZIP
2. Otevři složku Vcelka-Budik-V77-FIXED v Android Studio
3. Pokud se zeptá na Upgrade Assistant, dej Cancel - už je opraveno
4. Build -> Build APK(s)
5. APK najdeš v app/build/outputs/apk/debug/app-debug.apk
