
# Včelka Budík V77 - ONLINE sestavení APK bez Android Studia

Tento balík už obsahuje GitHub Actions workflow co sestaví APK automaticky v cloudu.

## Postup (2 minuty, bez instalace):

1. Jdi na https://github.com/new
   - Vytvoř nový repozitář, např. `vcelka-budik`
   - Nezaškrtávej README, nech prázdný

2. Na stránce repozitáře klikni `Add file -> Upload files`
   - Přetáhni SEM VŠECHNY soubory a složky z tohoto ZIPu (včetně složky .github)
   - Dole dej `Commit changes`

3. Klikni nahoře na záložku `Actions`
   - Uvidíš workflow `Build Vcelka Budik APK` - klikni na něj
   - Pokud je tlačítko `Run workflow`, klikni a spusť
   - Počkej 2-3 minuty až doběhne (zelená fajfka)

4. Klikni na poslední běh workflow, dole v `Artifacts` bude `Vcelka-Budik-V77-APK`
   - Stáhni ZIP, uvnitř je `app-debug.apk`
   - Zkopíruj do mobilu a nainstaluj

Hotovo! Žádné Android Studio, žádný JDK 25 problém.

## Alternativa - Codemagic (ještě jednodušší):
- Jdi na https://codemagic.io
- Přihlas se přes GitHub
- Přidej repozitář vcelka-budik
- Dá Build -> Android -> Debug APK -> stáhni

Primární funkce: systémový budík Android 10+ - probudí ze spánku, spořiče, zámku, přehraje YouTube Music URL.
